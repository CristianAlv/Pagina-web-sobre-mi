This template / effect / code has been created by Mohammad Abdul Mohaiman.
You can customize and check it out on its original site on the following link:
https://codepen.io/mohaiman/pen/MQqMyo

Thank you